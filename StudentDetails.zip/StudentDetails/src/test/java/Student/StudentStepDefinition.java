package Student;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


import BeanPageFactory.StudentPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class StudentStepDefinition {
	
	WebDriver driver;
private StudentPageFactory studentPageFactoryObject;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",

				  "C:\\Users\\vennrao\\Desktop\\chromedriver.exe");

		driver= new ChromeDriver();
	}
	
	@Given("^user is on Personal Details Page$")
	public void user_is_on_Personal_Details_Page() throws Throwable {
		driver.get("C:\\Users\\vennrao\\Desktop\\StudentDetails\\PersonalDetails.html");
		studentPageFactoryObject=new StudentPageFactory(driver);
	}

	@Then("^check the heading 'Personal Details'$")
	public void check_the_heading_Personal_Details() throws Throwable {
		String expectedTitle="Personal Details";
		Assert.assertEquals(expectedTitle,driver.getTitle());
	}

	@When("^user left the First Name field empty$")
	public void user_left_the_First_Name_field_empty() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("");
	}

	@Then("^click on Confirm Booking button$")
	public void click_on_Confirm_Booking_button() throws Throwable {
		studentPageFactoryObject.setNextLink();
	}

	@Then("^it will pop-up the alert box displays the message Please fill the First Name$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_First_Name() throws Throwable {

		String expectedMessage1="Please fill the First Name";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user left the Last Name field empty$")
	public void user_left_the_Last_Name_field_empty() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("Chandra");
		studentPageFactoryObject.setTxtLastName("");
	}

	@Then("^it will pop-up the alert box displays the message Please fill the Last Name$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage1="Please fill the Last Name";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user gives invalid Email$")
	public void user_gives_invalid_Email() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("Chandra");
		studentPageFactoryObject.setTxtLastName(" Muthu");
		studentPageFactoryObject.setTxtEmail("");
	}

	@Then("^it will pop-up the alert box displays the message Please fill the Email$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Email() throws Throwable {
		String expectedMessage1="Please fill the Email";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user gives invalid Contact Number$")
	public void user_gives_invalid_Contact_Number() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("Chandra");
		studentPageFactoryObject.setTxtLastName(" Muthu");
		studentPageFactoryObject.setTxtEmail("Chandramuthu36@gmail.com");
		studentPageFactoryObject.setTxtPhone("");
	}

	@Then("^it will pop-up the alert box displays the message Please fill the Contact No\\.$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Contact_No() throws Throwable {
		String expectedMessage1="Please fill the Contact No.";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user gives invalid First Address$")
	public void user_gives_invalid_First_Address() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("Chandra");
		studentPageFactoryObject.setTxtLastName(" Muthu");
		studentPageFactoryObject.setTxtEmail("Chandramuthu36@gmail.com");
		studentPageFactoryObject.setTxtPhone("9844512477");
		studentPageFactoryObject.setTxtAddress1("");
	}

	@Then("^it will pop-up the alert box displays the message Please fill the first address line$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_first_address_line() throws Throwable {
		String expectedMessage1="Please fill the address line 1";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user gives invalid Second Address$")
	public void user_gives_invalid_Second_Address() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("Chandra");
		studentPageFactoryObject.setTxtLastName(" Muthu");
		studentPageFactoryObject.setTxtEmail("Chandramuthu36@gmail.com");
		studentPageFactoryObject.setTxtPhone("9844512477");
		studentPageFactoryObject.setTxtAddress1("Goripalya");
		studentPageFactoryObject.setTxtAddress2("");
	}

	@Then("^it will pop-up the alert box displays the message Please fill the second address line$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_second_address_line() throws Throwable {
		String expectedMessage1="Please fill the address line 2";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user gives invalid city$")
	public void user_gives_invalid_city() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("Chandra");
		studentPageFactoryObject.setTxtLastName(" Muthu");
		studentPageFactoryObject.setTxtEmail("Chandramuthu36@gmail.com");
		studentPageFactoryObject.setTxtPhone("9844512477");
		studentPageFactoryObject.setTxtAddress1("Goripalya");
		studentPageFactoryObject.setTxtAddress2("Rayapuram");
		studentPageFactoryObject.setCity("Select City");
	}

	@Then("^it will pop-up the alert box displays the message Please fill the city$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_city() throws Throwable {
		String expectedMessage1="Please select city";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user gives invalid state$")
	public void user_gives_invalid_state() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("Chandra");
		studentPageFactoryObject.setTxtLastName(" Muthu");
		studentPageFactoryObject.setTxtEmail("Chandramuthu36@gmail.com");
		studentPageFactoryObject.setTxtPhone("9844512477");
		studentPageFactoryObject.setTxtAddress1("Goripalya");
		studentPageFactoryObject.setTxtAddress2("Rayapuram");
		studentPageFactoryObject.setCity("Bangalore");
		studentPageFactoryObject.setState("Select State");
	}

	@Then("^it will pop-up the alert box displays the message Please fill the state$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_state() throws Throwable {
		String expectedMessage1="Please select state";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}
	
	@When("^user gives valid Personal Details$")
	public void user_gives_valid_Personal_Details() throws Throwable {
		studentPageFactoryObject.setTxtFirstName("Chandra");
		studentPageFactoryObject.setTxtLastName(" Muthu");
		studentPageFactoryObject.setTxtEmail("Chandramuthu36@gmail.com");
		studentPageFactoryObject.setTxtPhone("9844512477");
		studentPageFactoryObject.setTxtAddress1("Goripalya");
		studentPageFactoryObject.setTxtAddress2("Rayapuram");
		studentPageFactoryObject.setCity("Bangalore");
		studentPageFactoryObject.setState("Karnataka");
	}

	@Then("^Go to Education details page$")
	public void go_to_Education_details_page() throws Throwable {
		String expectedMessage1="Personal details are validated and accepted successfully.";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
		driver.get("C:\\Users\\cv4\\Desktop\\java fullstack\\BDD Workspace 2nd\\StudentDetails\\EducationalDetails.html");
	
		driver.close();
	}

	
	

}
