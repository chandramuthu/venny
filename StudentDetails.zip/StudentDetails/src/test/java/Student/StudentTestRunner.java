package Student;


import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\vennrao\\Desktop\\StudentDetails\\src\\test\\resources\\StudentResource\\student.feature"},
		glue= {"Student"},
		dryRun=false,
		monochrome=true,
		strict=false,
		plugin= {"pretty","html:TestOutput"}
		)






public class StudentTestRunner {

}
