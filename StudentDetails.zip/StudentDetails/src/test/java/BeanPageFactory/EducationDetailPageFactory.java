package BeanPageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class EducationDetailPageFactory {
	WebDriver driver;

	public EducationDetailPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	
	@FindBy(name="graduation")
	@CacheLookup
	WebElement graduation;
	
	@FindBy(name="percentage")
	@CacheLookup
	WebElement percentage;
	
	@FindBy(name="passingYear")
	@CacheLookup
	WebElement passingYear;
	
	@FindBy(id="txtProjectName")
	@CacheLookup
	WebElement txtProjectName;
	
	
	@FindBy(id="btnRegister")
	@CacheLookup
	WebElement btnRegister;
	
	@FindBy(id="txtOtherTechs")
	@CacheLookup
	WebElement txtOtherTechs;
	
	
	
	public WebElement getTxtOtherTechs() {
		return txtOtherTechs;
	}


	public void setTxtOtherTechs(String txtOtherTechs) {
		this.txtOtherTechs.sendKeys(txtOtherTechs);
	}



	@FindBy(xpath="//input[@value=\"Java\"]")
	@CacheLookup
	WebElement javatechnologies;
	
	@FindBy(xpath="//input[@value=\"Other\"]")
	@CacheLookup
	WebElement othertechnologies;

	public WebElement getJavatechnologies() {
		return javatechnologies;
	}


	public void setJavatechnologies() {
		javatechnologies.click();
	}


	public WebElement getOthertechnologies() {
		return othertechnologies;
	}


	public void setOthertechnologies() {
		othertechnologies.click();
	}


	public WebElement getGraduation() {
		return graduation;
	}


	public void setGraduation(String graduation) {
		this.graduation.sendKeys(graduation);
	}


	public WebElement getPercentage() {
		return percentage;
	}


	public void setPercentage(String percentage) {
		this.percentage.sendKeys(percentage);
	}


	public WebElement getPassingYear() {
		return passingYear;
	}


	public void setPassingYear(String passingYear) {
		this.passingYear.sendKeys(passingYear);
	}


	public WebElement getTxtProjectName() {
		return txtProjectName;
	}


	public void setTxtProjectName(String txtProjectName) {
		this.txtProjectName.sendKeys(txtProjectName);
	}


	public WebElement getBtnRegister() {
		return btnRegister;
	}


	public void setBtnRegister() {
		this.btnRegister.click();
	}
	
	
}
