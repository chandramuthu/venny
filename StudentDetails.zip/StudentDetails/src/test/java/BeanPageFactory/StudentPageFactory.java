package BeanPageFactory;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;



public class StudentPageFactory {
WebDriver driver;
	
	public StudentPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
}
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement txtFirstName;
	
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement txtLastName;

	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement txtEmail;

	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement txtPhone;

	
	@FindBy(id="txtAddress1")
	@CacheLookup
	WebElement txtAddress1;
	

	@FindBy(id="txtAddress2")
	@CacheLookup
	WebElement txtAddress2;

	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;

	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	
	@FindBy(xpath="html//body//form//table//tbody//tr//td//a")
	@CacheLookup
	WebElement nextLink;

	public WebDriver getDriver() {
		return driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}


	public WebElement getTxtFirstName() {
		return txtFirstName;
	}


	public void setTxtFirstName(String txtFirstName) {
		this.txtFirstName.sendKeys(txtFirstName);
	}


	public WebElement getTxtLastName() {
		return txtLastName;
	}


	public void setTxtLastName(String txtLastName) {
		this.txtLastName.sendKeys(txtLastName);
	}


	public WebElement getTxtEmail() {
		return txtEmail;
	}


	public void setTxtEmail(String txtEmail) {
		this.txtEmail.sendKeys(txtEmail);
	}


	public WebElement getTxtPhone() {
		return txtPhone;
	}


	public void setTxtPhone(String txtPhone) {
		this.txtPhone.sendKeys(txtPhone);
	}


	public WebElement getTxtAddress1() {
		return txtAddress1;
	}


	public void setTxtAddress1(String txtAddress1) {
		this.txtAddress1.sendKeys(txtAddress1);
	}


	public WebElement getTxtAddress2() {
		return txtAddress2;
	}


	public void setTxtAddress2(String txtAddress2) {
		this.txtAddress2.sendKeys(txtAddress2);
	}


	public WebElement getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city.sendKeys(city);
	}


	public WebElement getState() {
		return state;
	}


	public void setState(String state) {
		this.state.sendKeys(state);
	}


	public WebElement getNextLink() {
		return nextLink;
	}


	public void setNextLink() {
		this.nextLink.click();
	}
	

	/*public void setYear(String year) {
		this.year.sendKeys(year);
	}

	public void setConfirmButton() {
		this.confirmButton.click();
	}

	public WebElement getCity() {
		Select City_Select = new Select(city);
		return City_Select.getFirstSelectedOption();
		
	}*/
	
	
	
	


}