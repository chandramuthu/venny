package EducationDetail;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import BeanPageFactory.EducationDetailPageFactory;
import BeanPageFactory.StudentPageFactory;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationDetailStepDefinition {
	WebDriver driver;
	private EducationDetailPageFactory educationDetailPageFactoryObject;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\chandru\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	@Given("^user is on Education Details Page$")
	public void user_is_on_Education_Details_Page() throws Throwable {
		driver.get("C:\\Users\\cv4\\Desktop\\java fullstack\\BDD Workspace 2nd\\StudentDetails\\EducationalDetails.html");
		educationDetailPageFactoryObject=new EducationDetailPageFactory(driver); //Creating object for page factory
	}

	@Then("^check the title 'Education Details'$")
	public void check_the_title_Education_Details() throws Throwable {
		String expectedTitle="Educational Details";
		Assert.assertEquals(expectedTitle,driver.getTitle());
		System.out.println(driver.getTitle());
	}

	@When("^user gave invalid graduation$")
	public void user_gave_invalid_graduation() throws Throwable {
	    educationDetailPageFactoryObject.setGraduation("Select graduation");
	}

	@Then("^click on Register Me button$")
	public void click_on_Register_Me_button() throws Throwable {
	  educationDetailPageFactoryObject.setBtnRegister();
	}

	@Then("^it will pop-up the alert box displays the message Please Select Graduation$")
	public void it_will_pop_up_the_alert_box_displays_the_message_Please_Select_Graduation() throws Throwable {
		String expectedMessage1="Please Select Graduation";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();//to accept that alert box
	
		driver.close();
	}

	@When("^user gave invalid percentage$")
	public void user_gave_invalid_percentage() throws Throwable {
		   educationDetailPageFactoryObject.setGraduation("BTech");
		   educationDetailPageFactoryObject.setPercentage("");
	    
	}

	
	
	
	@Then("^it will pop-up the alerthe alert bot box displays the message Please fill the percentage$")
	public void it_will_pop_up_the_alerthe_alert_bot_box_displays_the_message_Please_fill_the_percentage() throws Throwable {
		String expectedMessage1="Please fill Percentage detail";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@Then("^it will pop-up the alerthe alert bot box displays the message Please fill the year$")
	public void it_will_pop_up_the_alerthe_alert_bot_box_displays_the_message_Please_fill_the_year() throws Throwable {
		String expectedMessage1="Please fill Passing Year";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@Then("^it will pop-up the alerthe alert bot box displays the message Please fill the project Name$")
	public void it_will_pop_up_the_alerthe_alert_bot_box_displays_the_message_Please_fill_the_project_Name() throws Throwable {
		String expectedMessage1="Please fill Project Name";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user gave invalid passing year$")
	public void user_gave_invalid_passing_year() throws Throwable {
		 educationDetailPageFactoryObject.setGraduation("BTech");
		   educationDetailPageFactoryObject.setPercentage("85");
		   educationDetailPageFactoryObject.setPassingYear("");
	}

	@When("^user gave invalid Project Name$")
	public void user_gave_invalid_Project_Name() throws Throwable {
		 educationDetailPageFactoryObject.setGraduation("BTech");
		   educationDetailPageFactoryObject.setPercentage("85");
		   educationDetailPageFactoryObject.setPassingYear("2014");
		   educationDetailPageFactoryObject.setTxtProjectName("");
	}

	@When("^user gave valid Details$")
	public void user_gave_valid_Details() throws Throwable {
		educationDetailPageFactoryObject.setGraduation("BTech");
		   educationDetailPageFactoryObject.setPercentage("85");
		   educationDetailPageFactoryObject.setPassingYear("2014");
		   educationDetailPageFactoryObject.setTxtProjectName("Full Stack");
		   educationDetailPageFactoryObject.setJavatechnologies();
	  
	}

	@Then("^it will pop-up the alerthe alert bot box displays the message Your Registration Has succesfully done Plz check you registerd email for account activation link !!!$")
	public void it_will_pop_up_the_alerthe_alert_bot_box_displays_the_message_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {
		String expectedMessage1="Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}
	
	
	@When("^user dont dont click any technology$")
	public void user_dont_dont_click_any_technology() throws Throwable {
		educationDetailPageFactoryObject.setGraduation("BTech");
		   educationDetailPageFactoryObject.setPercentage("85");
		   educationDetailPageFactoryObject.setPassingYear("2014");
		   educationDetailPageFactoryObject.setTxtProjectName("Full Stack");
	}

	@Then("^it will pop-up the alerthe alert bot box displays the message Please select technology used$")
	public void it_will_pop_up_the_alerthe_alert_bot_box_displays_the_message_Please_select_technology_used() throws Throwable {
		String expectedMessage1="Please Select Technologies Used";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	@When("^user gave invalid other technology details$")
	public void user_gave_invalid_other_technology_details() throws Throwable {
		educationDetailPageFactoryObject.setGraduation("BTech");
		   educationDetailPageFactoryObject.setPercentage("85");
		   educationDetailPageFactoryObject.setPassingYear("2014");
		   educationDetailPageFactoryObject.setTxtProjectName("Full Stack");
		   educationDetailPageFactoryObject.setOthertechnologies();
		   educationDetailPageFactoryObject.setTxtOtherTechs("");
		   
	}

	@Then("^it will pop-up the alerthe alert bot box displays the message Please fill other technology used$")
	public void it_will_pop_up_the_alerthe_alert_bot_box_displays_the_message_Please_fill_other_technology_used() throws Throwable {
		String expectedMessage1="Please fill other Technologies Used";
		String actualMessage1=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage1, actualMessage1);
		
		driver.switchTo().alert().accept();
	
		driver.close();
	}

	
	
	
	

	
	
}
