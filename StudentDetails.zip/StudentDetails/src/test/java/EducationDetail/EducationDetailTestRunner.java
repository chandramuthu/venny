package EducationDetail;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\cv4\\Desktop\\java fullstack\\BDD Workspace 2nd\\StudentDetails\\src\\test\\resources\\StudentResource\\Education.feature"},
		glue= {"EducationDetail"},
		dryRun=false,
		monochrome=true,
		strict=false,
		plugin= {"pretty","html:TestOutput"}
		)


public class EducationDetailTestRunner {

	
	
	
}
