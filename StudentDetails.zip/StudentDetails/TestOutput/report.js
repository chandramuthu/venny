$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/vennrao/Desktop/StudentDetails/src/test/resources/StudentResource/student.feature");
formatter.feature({
  "line": 1,
  "name": "Personal Details",
  "description": "",
  "id": "personal-details",
  "keyword": "Feature"
});
formatter.before({
  "duration": 9660381000,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "check the title",
  "description": "",
  "id": "personal-details;check-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "check the heading \u0027Personal Details\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 1319045200,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.check_the_heading_Personal_Details()"
});
formatter.result({
  "duration": 18735400,
  "status": "passed"
});
formatter.before({
  "duration": 3143170500,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "the alert box displays the message Please fill the First Name upon clicking on the link Next without entering any data in the text box",
  "description": "",
  "id": "personal-details;the-alert-box-displays-the-message-please-fill-the-first-name-upon-clicking-on-the-link-next-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user left the First Name field empty",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "it will pop-up the alert box displays the message Please fill the First Name",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 174000600,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_left_the_First_Name_field_empty()"
});
formatter.result({
  "duration": 542199800,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 98396700,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_First_Name()"
});
formatter.result({
  "duration": 610010700,
  "status": "passed"
});
formatter.before({
  "duration": 1588209400,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "the alert box displays the message Please fill the Last Name upon clicking on the link Next without entering any data in the text box",
  "description": "",
  "id": "personal-details;the-alert-box-displays-the-message-please-fill-the-last-name-upon-clicking-on-the-link-next-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "user left the Last Name field empty",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 18,
  "name": "it will pop-up the alert box displays the message Please fill the Last Name",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 123376000,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_left_the_Last_Name_field_empty()"
});
formatter.result({
  "duration": 187969000,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 72637800,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Last_Name()"
});
formatter.result({
  "duration": 337035700,
  "status": "passed"
});
formatter.before({
  "duration": 2016562200,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "the alert box displays the message Please fill the Email upon clicking on the link Next without entering any data in the text box",
  "description": "",
  "id": "personal-details;the-alert-box-displays-the-message-please-fill-the-email-upon-clicking-on-the-link-next-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 22,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "user gives invalid Email",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 25,
  "name": "it will pop-up the alert box displays the message Please fill the Email",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 989541300,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_gives_invalid_Email()"
});
formatter.result({
  "duration": 237650600,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 80343100,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Email()"
});
formatter.result({
  "duration": 194256100,
  "status": "passed"
});
formatter.before({
  "duration": 1582075900,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "the alert box displays the message Please fill the Contact No. upon clicking on the link Next without entering any data in the text box",
  "description": "",
  "id": "personal-details;the-alert-box-displays-the-message-please-fill-the-contact-no.-upon-clicking-on-the-link-next-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "user gives invalid Contact Number",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 31,
  "name": "it will pop-up the alert box displays the message Please fill the Contact No.",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 1454907400,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_gives_invalid_Contact_Number()"
});
formatter.result({
  "duration": 464688600,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 78731300,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_Contact_No()"
});
formatter.result({
  "duration": 330534900,
  "status": "passed"
});
formatter.before({
  "duration": 2581558500,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "the alert box displays the message Please fill the Address1 upon clicking on the link Next without entering any data in the text box",
  "description": "",
  "id": "personal-details;the-alert-box-displays-the-message-please-fill-the-address1-upon-clicking-on-the-link-next-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "user gives invalid First Address",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 38,
  "name": "it will pop-up the alert box displays the message Please fill the first address line",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 1034054500,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_gives_invalid_First_Address()"
});
formatter.result({
  "duration": 515441100,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 75240100,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_first_address_line()"
});
formatter.result({
  "duration": 199995800,
  "status": "passed"
});
formatter.before({
  "duration": 1577875900,
  "status": "passed"
});
formatter.scenario({
  "line": 41,
  "name": "the alert box displays the message Please fill the Addres2 upon clicking on the link Next without entering any data in the text box",
  "description": "",
  "id": "personal-details;the-alert-box-displays-the-message-please-fill-the-addres2-upon-clicking-on-the-link-next-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 42,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "user gives invalid Second Address",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 45,
  "name": "it will pop-up the alert box displays the message Please fill the second address line",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 1182694600,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_gives_invalid_Second_Address()"
});
formatter.result({
  "duration": 557728200,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 68584500,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_second_address_line()"
});
formatter.result({
  "duration": 239238100,
  "status": "passed"
});
formatter.before({
  "duration": 2058731200,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "the alert box displays the message Please fill the city upon clicking on the link Next without entering any data in the text box",
  "description": "",
  "id": "personal-details;the-alert-box-displays-the-message-please-fill-the-city-upon-clicking-on-the-link-next-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 48,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 49,
  "name": "user gives invalid city",
  "keyword": "When "
});
formatter.step({
  "line": 50,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 51,
  "name": "it will pop-up the alert box displays the message Please fill the city",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 1399356700,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_gives_invalid_city()"
});
formatter.result({
  "duration": 597541100,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 70918500,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_city()"
});
formatter.result({
  "duration": 193304400,
  "status": "passed"
});
formatter.before({
  "duration": 1396797200,
  "status": "passed"
});
formatter.scenario({
  "line": 53,
  "name": "the alert box displays the message Please fill the state upon clicking on the link Next without entering any data in the text box",
  "description": "",
  "id": "personal-details;the-alert-box-displays-the-message-please-fill-the-state-upon-clicking-on-the-link-next-without-entering-any-data-in-the-text-box",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 54,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 55,
  "name": "user gives invalid state",
  "keyword": "When "
});
formatter.step({
  "line": 56,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 57,
  "name": "it will pop-up the alert box displays the message Please fill the state",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 3020388000,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_gives_invalid_state()"
});
formatter.result({
  "duration": 680994600,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 96354800,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.it_will_pop_up_the_alert_box_displays_the_message_Please_fill_the_state()"
});
formatter.result({
  "duration": 438183100,
  "status": "passed"
});
formatter.before({
  "duration": 1752427800,
  "status": "passed"
});
formatter.scenario({
  "line": 60,
  "name": "Valid Input",
  "description": "",
  "id": "personal-details;valid-input",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 61,
  "name": "user is on Personal Details Page",
  "keyword": "Given "
});
formatter.step({
  "line": 62,
  "name": "user gives valid Personal Details",
  "keyword": "When "
});
formatter.step({
  "line": 63,
  "name": "click on Confirm Booking button",
  "keyword": "Then "
});
formatter.step({
  "line": 64,
  "name": "Go to Education details page",
  "keyword": "Then "
});
formatter.match({
  "location": "StudentStepDefinition.user_is_on_Personal_Details_Page()"
});
formatter.result({
  "duration": 135326200,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.user_gives_valid_Personal_Details()"
});
formatter.result({
  "duration": 708122000,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.click_on_Confirm_Booking_button()"
});
formatter.result({
  "duration": 66741800,
  "status": "passed"
});
formatter.match({
  "location": "StudentStepDefinition.go_to_Education_details_page()"
});
formatter.result({
  "duration": 1540758100,
  "status": "passed"
});
});